<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="terrainTiles_default" tilewidth="32" tileheight="32" tilecount="160" columns="20">
 <image source="../Tilesheet/terrainTiles_default.png" width="640" height="256"/>
</tileset>
